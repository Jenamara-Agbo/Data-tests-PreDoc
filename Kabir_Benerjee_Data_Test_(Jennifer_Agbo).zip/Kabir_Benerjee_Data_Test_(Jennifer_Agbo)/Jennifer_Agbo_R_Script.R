#Installing Packages
install.packages("dplyr")
install.packages("broom")
install.packages("fixest")
install.packages("ggplot2")
install.packages("stargazer")

#load library
library(dplyr)
library(tidyr)
library(broom)
library(fixest)
library(ggplot2)
library(stargazer)

#set the data and output path
data_path <- "C:/Users/jaa262/Downloads/Kabir_Benerjee_Data_Test_(Jennifer_Agbo)/Raw_Data/"
output_path <- "C:/Users/jaa262/Downloads/Kabir_Benerjee_Data_Test_(Jennifer_Agbo)/Processed_Data/"
table_path <- "C:/Users/jaa262/Downloads/Kabir_Benerjee_Data_Test_(Jennifer_Agbo)/tables/" 

# Load the raw datasets
schools <- read.csv(paste0(data_path, "schools.csv"))
school_visits <- read.csv(paste0(data_path, "school_visits_log.csv"))
student_baseline <- read.csv(paste0(data_path, "student_baseline.csv"))
student_followups <- read.csv(paste0(data_path, "student_follow_ups.csv"))

# View the first few rows
head(schools)
head(school_visits)
head(student_baseline)
head(student_followups)

# Inspect the structure of each dataset
str(schools)
str(school_visits)
str(student_baseline)
str(student_followups)

#=====================================================================================================
#1) PRELIMINARY DATA TIDYING TO CHECK FOR DATA QUALITY 

#A) Check for count of missing values (NAs) for each column of the datasets
# Function to count missing values (both NA and -99)
count_missing <- function(df) {
  df %>%
    summarise(across(everything(), ~ sum(is.na(.x) | .x == -99)))
}

# Check missing values in each dataset
missing_schools <- count_missing(schools)
missing_visits <- count_missing(school_visits)
missing_students_baseline <- count_missing(student_baseline)
missing_students_followup <- count_missing(student_followups)

# Print results
list(
  schools = missing_schools,
  student_baseline = missing_students_baseline,
  student_followups = missing_students_followup,
  school_visits = missing_visits
)

#None of the missing values would be dropped yet. This is only an inpection
#=====================================================================================================

#B) Summary function for datasets
summary_info <- function(df) {
  list(
    Dimensions = dim(df),
    Summary = summary(df)
  )
}

# Get summary info for all datasets
summary_schools <- summary_info(schools)
summary_students_baseline <- summary_info(student_baseline)
summary_students_followup <- summary_info(student_followups)
summary_visits <- summary_info(school_visits)

# Print summaries
list(
  schools = summary_schools,
  student_baseline = summary_students_baseline,
  student_followups = summary_students_followup,
  school_visits = summary_visits
)

#===============================================================================================================================
#C) Handling -99 Properly: replace -99 with NA in both schools and student_followups (because -99 only appeared there) datasets

# Replace -99 with NA in some school.csv data columns
schools <- schools %>%
  mutate(across(c(av_teacher_age, av_student_score, n_latrines), ~ na_if(.x, -99)))
head(schools)

# Replace -99 with NA in some columns for student_followups
student_followups <- student_followups %>%
  mutate(across(c(died, married, children, pregnant), ~ na_if(.x, -99)))
head(student_followups)


#I noticed the "yob" column has some missing values in form of "9999", the will be replaced by NA
student_baseline <- student_baseline %>%
  mutate(yob = na_if(yob, 9999))

# Check if the replacement worked
summary(student_baseline$yob)

#===============================================================================================================================
#===============================================================================================================================
#2) RESHAPING THE DATA
#I reshaped the school_visits and student_followups datasets to a wide format compare the visits for each school across both years (3 & 5)
# This is so that I have one row per schooland/or student_id with separate columns for day and month in years 3 and 5.

# A) Reshape school visits from long to wide format
school_visits_wide <- school_visits %>%
  pivot_wider(names_from = year, values_from = c(day, month), names_prefix = "year_")

# View the reshaped dataset
glimpse(school_visits_wide)
head(school_visits_wide)

#===============================================================================================================================
# B) Reshape school_followups_data from long to wide format
student_followups_wide <- student_followups %>%
  pivot_wider(names_from = year, values_from = c(died, married, children, pregnant, dropout), 
              names_prefix = "year_")

# View the reshaped dataset
glimpse(student_followups_wide)
head(student_followups_wide)

#check the info of the reshaped data
dim(student_followups_wide)  # Returns (rows, columns)

#===============================================================================================================================
#===============================================================================================================================
#3) MERGING THE DATASET

#Unique_ID in each dataset:
#- school.csv = school.id
#- student_baseline.csv = student_id
#- student_follow_ups.csv = student_id
#- school_visits.csv = school_id

#A) Merge student baseline data with follow-up data using student_id
students_merged <- left_join(student_baseline, student_followups_wide, by = "student_id")
#view the merged data
head(students_merged)

#B) Merge the "students_merged" with school-level data using school_id
students_schools_merged <- left_join(students_merged, schools, by = "school_id")
#view the merged data
head(students_schools_merged)

#c) Merge with school visits log 
final_data <- left_join(students_schools_merged, school_visits_wide, by = "school_id")
head(final_data)

#===============================================================================================================================
#D) Convert Each List Column to Numeric to allow for proper analysis
final_data <- final_data %>%
  mutate(
    died_year_3 = as.numeric(sapply(died_year_3, function(x) ifelse(length(x) == 0, NA, x))),
    died_year_5 = as.numeric(sapply(died_year_5, function(x) ifelse(length(x) == 0, NA, x))),
    married_year_3 = as.numeric(sapply(married_year_3, function(x) ifelse(length(x) == 0, NA, x))),
    married_year_5 = as.numeric(sapply(married_year_5, function(x) ifelse(length(x) == 0, NA, x))),
    children_year_3 = as.numeric(sapply(children_year_3, function(x) ifelse(length(x) == 0, NA, x))),
    children_year_5 = as.numeric(sapply(children_year_5, function(x) ifelse(length(x) == 0, NA, x))),
    pregnant_year_3 = as.numeric(sapply(pregnant_year_3, function(x) ifelse(length(x) == 0, NA, x))),
    pregnant_year_5 = as.numeric(sapply(pregnant_year_5, function(x) ifelse(length(x) == 0, NA, x))),
    dropout_year_3 = as.numeric(sapply(dropout_year_3, function(x) ifelse(length(x) == 0, NA, x))),
    dropout_year_5 = as.numeric(sapply(dropout_year_5, function(x) ifelse(length(x) == 0, NA, x)))
  )

#D) Check structure after merging
glimpse(final_data)
dim(final_data) 
head(final_data)

#view the summary of the final data
summary(final_data)

# Save final merged dataset
write.csv(final_data, file = paste0(output_path, "final_data.csv"), row.names = FALSE)
print("final_data.csv saved successfully!")

#===============================================================================================================================
#===============================================================================================================================
#4) Checking Baseline Balance at the School Level: Before analyzing the impact of the education subsidy program, I need to ensure 
#that schools in the treatment and control groups were similar before the intervention because If they were significantly different at baseline, 
#it could bias the impact estimates.

#Thus, I compare key school characteristics across treatment (treatment = 1) and control (treatment = 0) schools. There will be no significant
#differences in these characteristics if schools were properly randomized before the program started.


# List of school-level variables to test: Each t-test checks whether the mean of a variable is significantly different between treatment and control schools.
school_vars <- c("n_teachers", "n_teachers_fem", "female_head_teacher",
                 "n_students_fem", "n_students_male", "n_schools_2km",
                 "av_teacher_age", "av_student_score", "n_latrines")

# Run t-tests for each variable
school_balance_tests <- lapply(school_vars, function(var) {
  t_test <- t.test(final_data[[var]] ~ final_data$treatment)
  tidy(t_test)  # Convert results to a readable format
})

# Combine results into a data frame
school_balance_results <- do.call(rbind, school_balance_tests)
school_balance_results$Variable <- school_vars  # Add variable names
print(school_balance_results)

# Convert to LaTeX format
stargazer(school_balance_results, summary = FALSE, type = "latex")
#===============================================================================================================================
#COMMENTS AND INTERPRETATION: 

#Some school characteristics are significantly different across groups, suggesting potential imbalance at baseline
#Statistically significant differences (p < 0.05) were observed in:

#The t-tests compare school characteristics between treatment and control groups. Significant differences (p < 0.05) in number of 
#female teachers, number of students, teacher age, student scores, and latrines indicate some imbalance despite randomization. 
#These variables should be controlled for in the regression analysis.
#===============================================================================================================================


#===============================================================================================================================
#===============================================================================================================================
#4) Check for baseline balance at the student level (sex, year of birth).

# List of student-level variables to test
student_vars <- c("sex", "yob")

# Run t-tests for each variable
student_balance_tests <- lapply(student_vars, function(var) {
  t_test <- t.test(final_data[[var]] ~ final_data$treatment)
  tidy(t_test)  # Convert results to a readable format
})

# Combine results into a data frame
student_balance_results <- do.call(rbind, student_balance_tests)
student_balance_results$Variable <- student_vars  # Add variable names

# Print results
print(student_balance_results)

#===============================================================================================================================
#COMMENTS AND INTERPRETATION:

#- Sex (-0.0107, p = 0.291) → The proportion of male and female students is similar across treatment and control groups. The p-value 
#(0.291) suggests no statistically significant difference.
#- Year of Birth (0.000652, p = 0.983) → The average birth year is nearly identical for treatment and control groups (1990 vs. 1990). 
#The high p-value (0.983) confirms no significant difference.
#- Conclusion: There is no evidence of systematic differences in student demographics between treatment and control groups, indicating 
#a well-randomized assignment at baseline.
#===============================================================================================================================


#===============================================================================================================================
#===============================================================================================================================
#5) Regression model, while Controlling for Imbalanced Variables

# I will Include the Identify Imbalanced School level Variables as Covariates in the Regression Models

#For estimating the effect of treatment on school dropout (school evasion) after 3 years:

# Run OLS regression controlling for imbalanced variables
model_dropout_3yr <- feols(dropout_year_3 ~ treatment + 
                             n_teachers + n_teachers_fem + 
                             n_students_fem + n_students_male + 
                             av_teacher_age + av_student_score + 
                             n_latrines, data = final_data)

# Summary of the model
summary(model_dropout_3yr)

#===============================================================================================================================
#Interpretation of Regression Results:

#Treatment (-0.018, p = 0.0274): The subsidy program reduced dropout rates by 1.8 percentage points after 3 years, and this effect is statistically significant at the 5% level.
#Number of latrines (-0.0030, p < 0.001): More latrines in schools are associated with lower dropout rates, and this effect is highly significant.
#Other covariates (number of teachers, female teachers, student numbers, teacher age, student scores): These variables do not have a statistically significant effect on dropout rates.
#Thus, The program significantly reduced dropout rates, but the effect is small. School infrastructure (latrines) also appears to play a role in keeping students enrolled.
#===============================================================================================================================



#===============================================================================================================================
#===============================================================================================================================
#6) Analyze Dropout After 5 Years

# Run regression for dropout at year 5
model_dropout_5yr <- feols(dropout_year_5 ~ treatment + n_teachers + n_teachers_fem +
                             n_students_fem + n_students_male + av_teacher_age +
                             av_student_score + n_latrines, data = final_data)

# Summary of the model
summary(model_dropout_5yr)

#===============================================================================================================================
#Interpretation of Regression Results:

#- Treatment Effect: The treatment significantly reduced dropout rates after 5 years (-0.035, p < 0.001), meaning students in treatment schools 
#were 3.5 percentage points less likely to drop out compared to those in control schools.
#Number of teachers and female teachers had no significant effect.
#The average teacher age was positively associated with dropout (0.0034, p = 0.022), indicating that schools with older teachers had slightly higher dropout rates.
#The average student score had a negative effect on dropout (-0.00063, p < 0.001), suggesting that better-performing students were less likely to drop out.
#More latrines were associated with lower dropout rates (-0.0055, p < 0.001), suggesting that better school facilities might encourage students to stay enrolled.

#Comparison to Dropout After 3 Years

#The treatment effect was stronger after 5 years (-3.5 pp) compared to 3 years (-1.8 pp), indicating the long-term benefits of the subsidy in reducing dropout.
#Academic performance (student scores) and school facilities (latrines) remained important predictors of dropout in both models.

#Conclusion: 
#The in-kind education subsidy had a stronger effect in the long run, significantly reducing dropout even after the intervention ended. Schools with better 
#facilities and higher-performing students also saw lower dropout rates
#===================================================================================================================================


#===============================================================================================================================
#===============================================================================================================================
#7) Analyze Secondary Outcomes
# I will Run regressions for teen pregnancy (pregnant_year_3, pregnant_year_5) and early marriage (married_year_3, married_year_5) to check if the intervention had broader impacts.

#7i) Teen Pregnancy Analysis

#A) Regression for Pregnancy After 3 Years
model_pregnancy_3yr <- feols(pregnant_year_3 ~ treatment + n_teachers + n_teachers_fem +
n_students_fem + n_students_male + av_teacher_age +
  av_student_score + n_latrines, data = final_data)
summary(model_pregnancy_3yr)

#===============================================================================================================================
#Interpretation of Regression Results:

#- Treatment Effect: The coefficient for treatment is -0.0167 (p = 0.128), meaning that students in treatment schools were 1.67 percentage points 
#less likely to be pregnant after 3 years, but this effect is not statistically significant at conventional levels (p > 0.05).
#Number of teachers & female teachers: No significant effect on pregnancy likelihood.
#Average teacher age: Positive but marginally significant (p = 0.061), suggesting that schools with older teachers may have slightly higher pregnancy rates.
#Number of latrines: Significant negative effect (-0.0043, p < 0.001) → Schools with better sanitation had lower teen pregnancy rates.

#Conclusion: 
#The subsidy program did not significantly reduce teen pregnancy after 3 years.
#School facilities (like latrines) seem to have a more significant effect, possibly due to better school conditions leading to higher attendance and lower dropout rates.
#===================================================================================================================================


#B) Regression for Pregnancy After 5 Years
model_pregnancy_5yr <- feols(pregnant_year_5 ~ treatment + n_teachers + n_teachers_fem +
                               n_students_fem + n_students_male + av_teacher_age +
                               av_student_score + n_latrines, data = final_data)
summary(model_pregnancy_5yr)

#===============================================================================================================================
#Interpretation of Regression Results:

#- Treatment Effect: The coefficient for treatment is -0.0287 (p = 0.0538), meaning that students in treatment schools were 2.87 percentage points 
#less likely to be pregnant after 5 years. This effect is marginally significant (p ≈ 0.054), suggesting a potential but weak impact of the subsidy on reducing teen pregnancy.
#Number of female teachers: Significant negative effect (-0.0079, p = 0.0133) → Schools with more female teachers had lower pregnancy rates.
#Number of latrines: Significant negative effect (-0.0063, p < 0.001) → Better sanitation is associated with lower teen pregnancy rates, reinforcing the earlier result from year 3.
#Other variables (teacher age, student gender composition, and student scores) were not significant.

#Conclusion: 
#After 5 years, the effect of the subsidy program on reducing teen pregnancy becomes slightly stronger but is still marginally significant.
#Having more female teachers and better sanitation (more latrines) were both significantly linked to lower teen pregnancy rates.
#This suggests that school environment factors play a key role in reducing early pregnancies, possibly by providing mentorship and better facilities that keep girls in school.
#===================================================================================================================================


#===================================================================================================================================
#7ii) Early Marriage Analysis

#A) Regression for Marriage After 3 Year
model_marriage_3yr <- feols(married_year_3 ~ treatment + n_teachers + n_teachers_fem +
                              n_students_fem + n_students_male + av_teacher_age +
                              av_student_score + n_latrines, data = final_data)
summary(model_marriage_3yr)

#===============================================================================================================================
#Interpretation of Regression Results:

#- The coefficient for treatment is -0.0105 (p = 0.0583), meaning that students in treatment schools were 1.05 percentage points less likely to be married after 3 years. 
#However, this effect is only marginally significant (p ≈ 0.058), meaning we cannot confidently conclude that the program reduced early marriage.
#More latrines were significantly associated with lower marriage rates (-0.0021, p < 0.001), consistent with findings on pregnancy.
#More female teachers were weakly associated with lower marriage rates (-0.0022, p ≈ 0.059), suggesting potential influence but not at a strong confidence level.
#Higher number of female students showed a weak positive association with early marriage (0.0001, p ≈ 0.066), but this result is not strongly significant

#Conclusion: 
#The intervention had a small and marginally significant effect in reducing early marriage after 3 years.
#Sanitation (latrines) and female teacher presence appear to be protective factors against early marriage.
#Other school characteristics did not show strong effects.
#===================================================================================================================================


#B) Regression for Marriage After 5 Years
model_marriage_5yr <- feols(married_year_5 ~ treatment + n_teachers + n_teachers_fem +
                              n_students_fem + n_students_male + av_teacher_age +
                              av_student_score + n_latrines, data = final_data)

summary(model_marriage_5yr)

#===============================================================================================================================
#Interpretation of Regression Results:

#- The coefficient for treatment is -0.0074 (p = 0.372), meaning that students in treatment schools were 0.74 percentage points 
#less likely to be married after 5 years, but this result is not statistically significant. Unlike the marginally significant reduction at 3 years, 
#the effect seems to fade over time, suggesting the intervention did not have a strong long-term impact on early marriage.

#More latrines were significantly associated with lower marriage rates (-0.0035, p < 0.001), reinforcing previous findings that better school infrastructure may reduce early marriage.
#More female teachers were significantly associated with lower marriage rates (-0.0056, p ≈ 0.0016), suggesting that having more female role models in schools may help delay marriage.
#A higher number of total teachers was positively associated with marriage (0.0053, p ≈ 0.017), though the reason for this association is unclear.
#Number of male and female students showed weak associations, with more female students slightly increasing marriage rates and more male students slightly decreasing them, but both effects are not statistically strong.

#Conclusion: 
#Unlike after 3 years, the intervention did not significantly reduce early marriage after 5 years.
#Better school infrastructure (latrines) and having more female teachers seem to reduce marriage rates.
#Other school-level characteristics have weak or mixed effects.
#===================================================================================================================================


#===============================================================================================================================
#===============================================================================================================================
#8) iF I had more time, I would also run regression to see the Gender-Specific Effects on Dropout
#That is, Run the dropout regression separately for boys and girls to see if the subsidy affected them differently.


#===============================================================================================================================
#===============================================================================================================================
#9) DATA VISUALIZATION AND PLOTTING

#A) Dropout Rates by Treatment Status

# Compute mean dropout rates
dropout_summary <- final_data %>%
  group_by(treatment) %>%
  summarise(
    dropout_3yr = mean(dropout_year_3, na.rm = TRUE),
    dropout_5yr = mean(dropout_year_5, na.rm = TRUE)
  ) %>%
  pivot_longer(cols = c(dropout_3yr, dropout_5yr), names_to = "year", values_to = "dropout_rate")

print(dropout_summary)

#plot
ggplot(dropout_summary, aes(x = year, y = dropout_rate, fill = factor(treatment))) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(
    title = "Dropout Rates by Treatment Status",
    x = "Follow-up Year",
    y = "Average Dropout Rate",
    fill = "Treatment Status"
  ) +
  scale_fill_manual(values = c("0" = "red", "1" = "blue"), labels = c("Control", "Treatment")) +
  theme_minimal()

#===============================================================================================================================

#B) Dropout Trends Over Time

# Compute mean dropout rates per year
dropout_trend <- final_data %>%
  group_by(treatment) %>%
  summarise(
    dropout_3yr = mean(dropout_year_3, na.rm = TRUE),
    dropout_5yr = mean(dropout_year_5, na.rm = TRUE)
  ) %>%
  pivot_longer(cols = c(dropout_3yr, dropout_5yr), names_to = "year", values_to = "dropout_rate") %>%
  mutate(year = ifelse(year == "dropout_3yr", 3, 5))  # Convert to numeric

# Create line chart
ggplot(dropout_trend, aes(x = year, y = dropout_rate, color = as.factor(treatment), group = treatment)) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  scale_color_manual(values = c("blue", "red"), labels = c("Control", "Treatment")) +
  labs(title = "Evolution of Dropout Rates Over Time", x = "Year", y = "Dropout Rate", color = "Group") +
  theme_minimal()


#===============================================================================================================================

#C) Evolution of dropout rates for treatment vs. control groups over the 3-year and 5-year follow-ups.

ggplot(dropout_summary, aes(x = year, y = dropout_rate, group = factor(treatment), color = factor(treatment))) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  labs(
    title = "Dropout Trends Over Time by Treatment Group",
    x = "Follow-up Year",
    y = "Dropout Rate",
    color = "Treatment Status"
  ) +
  scale_color_manual(values = c("0" = "red", "1" = "blue"), labels = c("Control", "Treatment")) +
  theme_minimal()

#===============================================================================================================================

#D) Pregnancy rates for treatment vs. control groups at 3-year and 5-year follow-ups.

pregnancy_summary <- final_data %>%
  group_by(treatment) %>%
  summarise(
    pregnancy_3yr = mean(pregnant_year_3, na.rm = TRUE),
    pregnancy_5yr = mean(pregnant_year_5, na.rm = TRUE)
  ) %>%
  pivot_longer(cols = c(pregnancy_3yr, pregnancy_5yr), names_to = "year", values_to = "pregnancy_rate")

ggplot(pregnancy_summary, aes(x = year, y = pregnancy_rate, fill = factor(treatment))) +
  geom_bar(stat = "identity", position = "dodge") +
  labs(
    title = "Teen Pregnancy Rates by Treatment Status",
    x = "Follow-up Year",
    y = "Average Pregnancy Rate",
    fill = "Treatment Status"
  ) +
  scale_fill_manual(values = c("0" = "red", "1" = "blue"), labels = c("Control", "Treatment")) +
  theme_minimal()


#===============================================================================================================================

#E) Evolution of early marriage rates across follow-ups.

marriage_summary <- final_data %>%
group_by(treatment) %>%
  summarise(
    marriage_3yr = mean(married_year_3, na.rm = TRUE),
    marriage_5yr = mean(married_year_5, na.rm = TRUE)
  ) %>%
  pivot_longer(cols = c(marriage_3yr, marriage_5yr), names_to = "year", values_to = "marriage_rate")

ggplot(marriage_summary, aes(x = year, y = marriage_rate, group = factor(treatment), color = factor(treatment))) +
  geom_line(size = 1) +
  geom_point(size = 3) +
  labs(
    title = "Early Marriage Trends Over Time",
    x = "Follow-up Year",
    y = "Marriage Rate",
    color = "Treatment Status"
  ) +
  scale_color_manual(values = c("0" = "red", "1" = "blue"), labels = c("Control", "Treatment")) +
  theme_minimal()

#===============================================================================================================================
#===============================================================================================================================

#END OF R SCRIPT


