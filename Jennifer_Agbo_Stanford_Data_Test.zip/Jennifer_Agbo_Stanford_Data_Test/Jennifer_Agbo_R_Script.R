#Installing Packages
install.packages("dplyr")
library(dplyr)
library(tidyr)

# Load the Individual_Survey CSV file
data_path <- "C:/Users/jaa262/Downloads/data_exercise_files/"
ind_survey <- read.csv(paste0(data_path, "individual_survey.csv"))

#Exploring the data structure and feataures
#head(ind_survey) 
#names(ind_survey)

#======================================================================================
#1. Checking duplicates
num_duplicates <- sum(duplicated(ind_survey$uniq_indiv_id_csv))
cat("Number of duplicates found:", num_duplicates, "\n")

#Removing duplicates if exists
if (num_duplicates > 0) {
  ind_survey <- ind_survey[!duplicated(ind_survey$uniq_indiv_id_csv), ]
  cat("Duplicates removed.\n")
} else {
  cat("No duplicates found.\n")
}

#--------------------------------------------------------------------------------------------
#2. Recode/relabel the respondent gender variable
ind_survey$gender <- ifelse(ind_survey$h45_gender_1 == 1, 1, 0)
#cat("Gender variable summary:\n")
#table(ind_survey$gender)

#---------------------------------------------------------------------------------------------
#3. Create dummy variables for employment status using the categorical variable `e1`
#From the code book, these are the categories - "Salaried, Apprentice, Occasional worker, Self-employed, Farmer

ind_survey <- ind_survey %>%
  mutate(
    salaried_dummy = ifelse(e1 == 1, 1, 0),
    apprentice_dummy = ifelse(e1 == 2, 1, 0),
    occasional_worker_dummy = ifelse(e1 == 3, 1, 0),
    self_employed_dummy = ifelse(e1 == 4, 1, 0),
    farmer_dummy = ifelse(e1 == 6, 1, 0)
  )

# Check the new dummy variables
cat("Summary of employment dummies:\n")
summary(ind_survey[, c("salaried_dummy", "apprentice_dummy", "occasional_worker_dummy", 
                       "self_employed_dummy", "farmer_dummy")])

#---------------------------------------------------------------------------------------------
#4. CMU Subscription Dummy
# cmu6 tracks the specific health insurance provider of the respondent based on the codebook
# Create a dummy for CMU subscription (cmu6 == 2)
ind_survey <- ind_survey %>%
  mutate(cmu_subscribed = ifelse(cmu6 == 2, 1, 0))

#---------------------------------------------------------------------------------------------
#5. CMU Awareness Dummy
#cmu9 represents whether the respondent has heard of the CMU program based on the codebook
# Create a dummy for CMU awareness (cmu9 == 1)
ind_survey <- ind_survey %>%
  mutate(cmu_awareness = ifelse(cmu9 == 1, 1, 0))

#---------------------------------------------------------------------------------------------
#6. Saving the dataset
write.csv(ind_survey, paste0(data_path, "individual_survey_new_V1.csv"), row.names = FALSE)
cat("Dataset saved as 'individual_survey_updated.csv' in the directory:", data_path, "\n")

#---------------------------------------------------------------------------------------------
#7. Regression: egress (using OLS) the CMU subscription dummy variable on treatment. Include location fixed effects in your specification. 
#Model Specification: 
#Dependent variable: cmu_subscribed 
#Independent variable: Treatment (1 if the respondent received CMU information delivery at baseline, 0 otherwise)
#Fixed effects: Location-specific effects controlled using location_id_str

#Running OLS Regression:
# Run the OLS regression with location fixed effects
ols_model <- lm(cmu_subscribed ~ Treatment + factor(location_id_str), data = ind_survey)
summary(ols_model)

#Intrepreation

#Coefficient of Treatment: The coefficient of -0.1964 means that receiving the CMU information delivery at baseline is associated with a 
#decrease of about 19.64 percentage points in the likelihood of subscribing to the CMU health insurance program, compared to those who did not receive the treatment.

#P-Value: The p-value of 0.0983 is greater than 0.05 but less than 0.10, meaning the effect is marginally significant at the 10% level.
#This shows weak evidence that the information delivery treatment had an effect on CMU subscription rates.
#I assumed a 10% significance level when I said that the p-value of 0.0983 indicates marginal significance.

#---------------------------------------------------------------------------------------------
#Alternatively, since cmu_subscribed is a binary variable I think a probit or logit model would be more appropriate to model the probability of CMU subscription
#I would have proceeded with that If I had more time
#---------------------------------------------------------------------------------------------


#---------------------------------------------------------------------------------------------
#8. Run a regression to identify the effect of CMU information delivery (i.e., treatment) at baseline on respondents’ CMU program subscription rate if the respondent is the head of household?

# Filter for heads of household
# variable in43 indicates whether the respondent is the head of household (with 1 = Yes and 0 = No)
hh_survey <- subset(ind_survey, in43 == 1)

#Run a Logistic Regression for heads of household
logit_hh_model <- glm(cmu_subscribed ~ Treatment, 
                      data = hh_survey, family = binomial(link = "logit"))

summary(logit_hh_model)

#---------------------------------------------------------------------------------------------
#Intrepreation

#Coefficient of Treatment: The coefficient of -0.14005 meaning that receiving the CMU information delivery at baseline is 
#associated with a 14 percentage point decrease in the log-odds of subscribing to the CMU program for heads of households compared to those who did not receive the treatment.
#The negative effect also suggest that the treatment has a slight negative association with subscription likelihood but this can't be concluded because the P-value is large

#P-Value: The p-value for Treatment is 0.710, which is above the 5% significance level.
#I fail to reject the null hypothesis, and there is no evidence to suggest that the CMU information delivery at baseline significantly affects the CMU subscription rate among heads of households.

#---------------------------------------------------------------------------------------------
#9. Merging Dataset - individual_survey and listing_survey

# Reading in the listing_survey dataset
data_path <- "C:/Users/jaa262/Downloads/data_exercise_files/"
listing_survey <- read.csv(paste0(data_path, "listing_survey.csv"))

#Check column names of the two datasets
#colnames(ind_survey)
#colnames(listing_survey)

# Merge the datasets using uniq_indiv_id_csv as the key
merged_data <- merge(ind_survey, listing_survey, by = "uniq_indiv_id_csv")

# Create a new binary variable for large/small families
#Large family: > 2 adults
#small family: =< 2 adults
merged_data$large_family <- ifelse(merged_data$nb_adult_bi18 > 2, "Large", "Small")

# Calculate the average CMU awareness for large and small families
average_cmu_awareness <- aggregate(cmu_awareness ~ large_family, data = merged_data, mean)
print(average_cmu_awareness)

#Answer  Large     0.5533905, Small     0.5846853

#---------------------------------------------------------------------------------------------
#10. PI presenting the results from this study to mayors of the municipalities of Abidjan only. 

#For variable abijan: 1 = lives in one of the Abidjan municipalities, 0 = not
# Filter the dataset for respondents in Abidjan only
abidjan_data <- subset(merged_data, abidjan_only == 1)

#Calculate average CMU awareness by treatment status
average_awareness <- abidjan_data %>%
  group_by(Treatment) %>%
  summarise(avg_cmu_awareness = mean(cmu_awareness, na.rm = TRUE))

#Create readable labels for Treatment
average_awareness$Treatment <- factor(average_awareness$Treatment, 
                                      levels = c(0, 1), 
                                      labels = c("Control", "Treatment"))


#Create the bar chart using ggplot2
library(ggplot2)

ggplot(average_awareness, aes(x = Treatment, y = avg_cmu_awareness, fill = Treatment)) +
  geom_bar(stat = "identity", width = 0.5, color = "black") +
  scale_fill_manual(values = c("skyblue", "coral")) +
  labs(title = "Average CMU Awareness by Treatment Status in Abidjan Only", 
       x = "Group", 
       y = "Average Awareness of CMU") +
  theme_minimal() +
  theme(legend.position = "none", 
        plot.title = element_text(hjust = 0.5, size = 14))


#---------------------------------------------------------------------------------------------
#11. Delivering the information to pregnant women visiting health centers 

# Reshape data: pivot child-specific columns into a long format
children_data <- ind_survey %>%
  pivot_longer(cols = starts_with("h45_"), 
               names_to = c(".value", "child_number"), 
               names_pattern = "h45_(.*)_(\\d+)") %>%
  filter(!is.na(birth_year))  # Keep only rows with child data
